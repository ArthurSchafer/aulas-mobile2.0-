// data/db.js
import * as SQLite from "expo-sqlite";

export const db = SQLite.openDatabaseSync("treinos.db");

export function initDb() {
  db.execSync(`
    PRAGMA journal_mode = WAL;
    CREATE TABLE IF NOT EXISTS treinos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      atividade TEXT NOT NULL,
      duracaoMin INTEGER NOT NULL,
      categoria TEXT NOT NULL,
      observacoes TEXT
    );
  `);

  // Tentar migrar se por acaso o nome antigo 'tarefas' existir:
  try {
    const rows = db.getAllSync("SELECT name FROM sqlite_master WHERE type='table' AND name='tarefas'");
    if (rows && rows.length > 0) {
      // copia dados da tabela antiga (se existir) para a nova tabela treinos, mapeando nome->atividade
      db.execSync(`
        INSERT INTO treinos (atividade, duracaoMin, categoria)
        SELECT nome, 0, 'Geral' FROM tarefas;
      `);
      // opcional: renomear ou remover tabela antiga
      // db.execSync('DROP TABLE IF EXISTS tarefas;');
    }
  } catch (e) {
    // não crítico — apenas seguiremos com a nova tabela
    console.warn("Migração tarefas -> treinos: ", e);
  }
}
