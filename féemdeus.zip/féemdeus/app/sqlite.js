// app/sqlite.js
import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  Button,
  StyleSheet,
  FlatList,
  TextInput,
  Alert,
  TouchableOpacity,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { db, initDb } from "../data/db";
import { useRouter } from "expo-router";

initDb();

function getTreinos() {
  return db.getAllSync("SELECT * FROM treinos ORDER BY id DESC");
}

function insertTreino(atividade, duracaoMin, categoria, observacoes) {
  db.runSync(
    "INSERT INTO treinos (atividade, duracaoMin, categoria, observacoes) VALUES (?, ?, ?, ?)",
    [atividade, duracaoMin, categoria, observacoes]
  );
}

function updateTreino(id, atividade, duracaoMin, categoria, observacoes) {
  db.runSync(
    "UPDATE treinos SET atividade = ?, duracaoMin = ?, categoria = ?, observacoes = ? WHERE id = ?",
    [atividade, duracaoMin, categoria, observacoes, id]
  );
}

function deleteTreino(id) {
  db.runSync("DELETE FROM treinos WHERE id = ?", [id]);
}

export default function TreinosScreen() {
  const router = useRouter();
  const [lista, setLista] = useState([]);
  const [atividade, setAtividade] = useState("");
  const [duracaoMin, setDuracaoMin] = useState("");
  const [categoria, setCategoria] = useState("");
  const [observacoes, setObservacoes] = useState("");
  const [editingId, setEditingId] = useState(null);

  function carregar() {
    try {
      const rows = getTreinos();
      setLista(rows ?? []);
    } catch (e) {
      console.error(e);
    }
  }

  useEffect(() => {
    carregar();
  }, []);

  function validarCampos() {
    if (!atividade || atividade.trim() === "") {
      Alert.alert("Erro", "Atividade não pode ficar vazia.");
      return false;
    }
    const dur = Number(duracaoMin);
    if (!duracaoMin || isNaN(dur) || dur <= 0) {
      Alert.alert("Erro", "Duração deve ser um número maior que 0.");
      return false;
    }
    if (!categoria || categoria.trim() === "") {
      Alert.alert("Erro", "Categoria não pode ficar vazia.");
      return false;
    }
    return true;
  }

  function onSalvar() {
    if (!validarCampos()) return;
    if (editingId) {
      updateTreino(editingId, atividade.trim(), Number(duracaoMin), categoria.trim(), observacoes.trim());
      setEditingId(null);
    } else {
      insertTreino(atividade.trim(), Number(duracaoMin), categoria.trim(), observacoes.trim());
    }
    setAtividade("");
    setDuracaoMin("");
    setCategoria("");
    setObservacoes("");
    carregar();
  }

  function onEditar(item) {
    setEditingId(item.id);
    setAtividade(item.atividade);
    setDuracaoMin(String(item.duracaoMin));
    setCategoria(item.categoria);
    setObservacoes(item.observacoes ?? "");
  }

  function onExcluir(id) {
    Alert.alert("Confirmar", "Deseja excluir este treino?", [
      { text: "Cancelar", style: "cancel" },
      {
        text: "Excluir",
        style: "destructive",
        onPress: () => {
          deleteTreino(id);
          if (editingId === id) {
            setEditingId(null);
            setAtividade("");
            setDuracaoMin("");
            setCategoria("");
            setObservacoes("");
          }
          carregar();
        },
      },
    ]);
  }

  const renderItem = ({ item }) => (
    <View style={styles.linha}>
      <View style={{ flex: 1 }}>
        <Text style={styles.titulo}>{item.atividade} ({item.categoria})</Text>
        <Text>⏱ {item.duracaoMin} min</Text>
        {item.observacoes ? <Text>Obs: {item.observacoes}</Text> : null}
      </View>
      <View style={styles.acoesLinha}>
        <TouchableOpacity onPress={() => onEditar(item)} style={styles.botaoPequeno}>
          <Text style={styles.botaoTexto}>Editar</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => onExcluir(item.id)} style={[styles.botaoPequeno, { backgroundColor: "#ff4444" }]}>
          <Text style={styles.botaoTexto}>Excluir</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View>
        <Text style={styles.header}>Cadastro de Treinos</Text>

        <TextInput
          placeholder="Atividade (ex: Musculação)"
          value={atividade}
          onChangeText={setAtividade}
          style={styles.input}
        />
        <TextInput
          placeholder="Duração em minutos (ex: 45)"
          value={duracaoMin}
          onChangeText={setDuracaoMin}
          keyboardType="numeric"
          style={styles.input}
        />
        <TextInput
          placeholder="Categoria (ex: Cardio, Força)"
          value={categoria}
          onChangeText={setCategoria}
          style={styles.input}
        />
        <TextInput
          placeholder="Observações (opcional)"
          value={observacoes}
          onChangeText={setObservacoes}
          style={styles.input}
        />

        <View style={styles.rodape}>
          <Button title={editingId ? "Atualizar" : "Salvar"} onPress={onSalvar} />
          <Button title="Limpar" onPress={() => { setEditingId(null); setAtividade(""); setDuracaoMin(""); setCategoria(""); setObservacoes(""); }} />
          <Button title="Novo (voltar)" onPress={() => router.back()} />
        </View>
      </View>

      <View style={{ marginTop: 16, flex: 1 }}>
        <Text style={{ fontWeight: "bold", marginBottom: 8 }}>Lista de treinos</Text>
        <FlatList
          data={lista}
          keyExtractor={(item) => String(item.id)}
          renderItem={renderItem}
          ItemSeparatorComponent={() => <View style={{ height: 8 }} />}
          ListEmptyComponent={() => <Text>Nenhum treino salvo.</Text>}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 12, flex: 1, backgroundColor: "#fff" },
  header: { fontSize: 20, fontWeight: "bold", marginBottom: 8 },
  input: {
    padding: 8,
    borderWidth: 1,
    borderColor: "#ddd",
    marginBottom: 8,
    borderRadius: 6,
  },
  linha: {
    padding: 8,
    borderWidth: 1,
    borderColor: "#eee",
    borderRadius: 8,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  titulo: { fontWeight: "700" },
  acoesLinha: {
    flexDirection: "column",
    gap: 6,
    marginLeft: 8,
  },
  botaoPequeno: {
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderRadius: 6,
    backgroundColor: "#333",
  },
  botaoTexto: { color: "#fff" },
  rodape: { flexDirection: "row", gap: 8, marginTop: 8, justifyContent: "space-between" },
});
